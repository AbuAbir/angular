import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.scss']
})
export class RegisterFormComponent implements OnInit {

  constructor(private user : UserService) { }

  ngOnInit(): void {
  }

  register(registerForm)
    {
      const { email, password, username } = registerForm.value;

        this.user.register(email, password, username )
    }

}
