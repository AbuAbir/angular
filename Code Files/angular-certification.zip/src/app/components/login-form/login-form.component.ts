import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { OrdersService } from 'src/app/services/orders.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.scss']
})
export class LoginFormComponent implements OnInit {


  loginForm = {
     email : "",
     password : ""
  }

  constructor(private user : UserService, private orders : OrdersService) { }

  ngOnInit(): void {
  }

  login(form){
      this.user.login(form.value.email, form.value.password).subscribe((response : any)=>{
          const { token } = response.data;
          window.localStorage.setItem("access-token", token);

          // Getting order for Users.
          this.orders.getOrders().subscribe((response)=>{
              console.log(response);
          })
      })
  }

}
